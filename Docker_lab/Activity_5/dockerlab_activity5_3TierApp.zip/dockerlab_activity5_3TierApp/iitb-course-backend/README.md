# 🎓 IITB Course Backend (Demo App)

This is a **Spring Boot backend** for the IIT Bombay Courses demo.
It exposes REST APIs for fetching, updating, and registering students in courses.
The backend uses **PostgreSQL** as the database, pre-loaded with dummy course data.

---

## ✨ Features

* 📡 REST APIs for:

  * Get all courses and details
  * Get course by code
  * Register a student
  * Update course details
  * Health check endpoint
* 🗄️ PostgreSQL persistence (data survives container restarts with a volume).
* 📑 DB schema and dummy data initialized via `schema.sql` + `data.sql`.
* 🛠️ Logging enabled — logs are written to console and files.
* 🐳 Packaged as a Docker image.

---

## ⚙️ APIs Exposed

### Health

* **GET `/api/health`** → returns `ok` if service is running.

### Courses

* **GET `/api/courses`** → list all courses.
* **GET `/api/courses/{code}`** → get details of a course by code.

### Student Registration

* **POST `/api/courses/{code}/register`**
  Request:

  ```json
  { "studentRoll": "19CS1234" }
  ```

  Response:

  ```json
  { "registrationId": 12, "registeredStudents": 5 }
  ```

### Course Update

* **PUT `/api/courses/{code}`**
  Request:

  ```json
  {
    "instructor": "Prof. New Name",
    "content": "Updated syllabus"
  }
  ```

---

## 🛠️ Run Locally (without Docker)

1. Make sure PostgreSQL is running:

   ```bash
   docker run -d \
     --name postgres \
     -e POSTGRES_USER=demo_user \
     -e POSTGRES_PASSWORD=demo_pass \
     -e POSTGRES_DB=demo_db \
     -p 5432:5432 \
     -v pgdata:/var/lib/postgresql/data \
     postgres:15
   ```

2. Run the Spring Boot app:

   ```bash
   export SPRING_DATASOURCE_URL=jdbc:postgresql://localhost:5432/demo_db; export SPRING_DATASOURCE_USERNAME=demo_user; export SPRING_DATASOURCE_PASSWORD=demo_pass
   mvn spring-boot:run
   ```

App will start on `http://localhost:8080`.

---

## 🐳 Running with Docker

### 1. Build image

```bash
docker build -t iitb-course-backend .
```

### 2. Run container (with Postgres already running)

```bash
docker run -d \
  --name backend \
  -p 8080:8080 \
  -e SPRING_DATASOURCE_URL=jdbc:postgresql://x.x.x.x:5432/demo_db \
  -e SPRING_DATASOURCE_USERNAME=demo_user \
  -e SPRING_DATASOURCE_PASSWORD=demo_pass \
  iitb-course-backend
```

Replace `x.x.x.x` with your host IP or service name if using Docker Compose.

---

## 🔗 Connecting with Frontend

Frontend expects backend APIs at `/api/**`.
If backend runs at `http://x.x.x.x:8080`, start frontend like:

```bash
docker run -d \
  --name frontend \
  -p 3000:80 \
  -e REACT_APP_API_BASE_URL="http://x.x.x.x:8080" \
  iitb-course-frontend
```

---

## 📂 Project Structure

```
src/main/java/org/iitb/demo
 ├── CourseBackendApplication.java   # main Spring Boot app
 ├── controller/CourseController.java # REST APIs
 ├── entity/…                        # JPA entities (Course, Registration, Grade)
 ├── repository/…                    # Spring Data repositories
 └── config/WebConfig or SecurityConfig # CORS configuration
```

---

## ⚠️ Notes

* This demo has **CORS open to all origins** (`*`) for convenience.
* Do not use this in production without tightening security.
* DB schema is auto-created using SQL scripts; in production you would use Flyway or Liquibase.
