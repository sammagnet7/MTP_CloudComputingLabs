package org.iitb.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourseBackendApplication {
    public static void main(String[] args) {
        SpringApplication.run(CourseBackendApplication.class, args);
    }
}
