// src/main/java/org/iitb/demo/config/WebConfig.java
package org.iitb.demo.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.lang.NonNull;

@Configuration
public class WebConfig implements WebMvcConfigurer {
    @Override
    public void addCorsMappings(@NonNull CorsRegistry registry) {
        registry.addMapping("/**") // apply to all endpoints
                .allowedOriginPatterns("*") // allow all origins
                .allowedMethods("*")        // allow all methods
                .allowedHeaders("*")        // allow all headers
                .allowCredentials(true)
                .maxAge(3600);
    }
}
