package org.iitb.demo.controller;

import org.iitb.demo.model.Course;
import org.iitb.demo.model.Grade;
import org.iitb.demo.model.Registration;
import org.iitb.demo.repository.CourseRepository;
import org.iitb.demo.repository.GradeRepository;
import org.iitb.demo.repository.RegistrationRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
public class CourseController {
    private static final Logger log = LoggerFactory.getLogger(CourseController.class);

    private final CourseRepository courseRepo;
    private final RegistrationRepository regRepo;
    private final GradeRepository gradeRepo;

    public CourseController(CourseRepository courseRepo, RegistrationRepository regRepo, GradeRepository gradeRepo) {
        this.courseRepo = courseRepo;
        this.regRepo = regRepo;
        this.gradeRepo = gradeRepo;
    }

    // Healthcheck
    @GetMapping("/health")
    public ResponseEntity<String> health() {
        log.debug("Health endpoint called");
        return ResponseEntity.ok("ok");
    }

    // List all courses with registration count and last-year grade distribution
    @GetMapping("/courses")
    public List<Map<String,Object>> listCourses() {
        log.info("Listing all courses");
        List<Course> courses = courseRepo.findAll();
        int lastYear = Calendar.getInstance().get(Calendar.YEAR) - 1;
        List<Map<String,Object>> out = new ArrayList<>();
        for (Course c : courses) {
            Map<String,Object> m = new HashMap<>();
            m.put("id", c.getId());
            m.put("courseCode", c.getCourseCode());
            m.put("courseName", c.getCourseName());
            m.put("instructor", c.getInstructor());
            m.put("content", c.getContent());
            m.put("semester", c.getSemester());

            long regCount = regRepo.countByCourseId(c.getId());
            m.put("registeredStudents", regCount);

            List<Grade> grades = gradeRepo.findByCourseIdAndYear(c.getId(), lastYear);
            Map<String, Long> gradeDist = grades.stream().collect(Collectors.groupingBy(Grade::getGrade, Collectors.counting()));
            m.put("lastYearGrades", gradeDist);

            out.add(m);
        }
        log.debug("Returning {} courses", out.size());
        return out;
    }

    // Get a single course by courseCode
    @GetMapping("/courses/{code}")
    public ResponseEntity<?> getCourseByCode(@PathVariable("code") String code) {
        log.info("Fetch course by code={}", code);
        Optional<Course> oc = courseRepo.findByCourseCode(code);
        if (oc.isEmpty()) {
            log.warn("Course not found: {}", code);
            return ResponseEntity.notFound().build();
        }
        Course c = oc.get();
        Map<String,Object> m = new HashMap<>();
        m.put("id", c.getId());
        m.put("courseCode", c.getCourseCode());
        m.put("courseName", c.getCourseName());
        m.put("instructor", c.getInstructor());
        m.put("content", c.getContent());
        m.put("semester", c.getSemester());
        long regCount = regRepo.countByCourseId(c.getId());
        m.put("registeredStudents", regCount);

        int lastYear = Calendar.getInstance().get(Calendar.YEAR) - 1;
        List<Grade> grades = gradeRepo.findByCourseIdAndYear(c.getId(), lastYear);
        Map<String, Long> gradeDist = grades.stream().collect(Collectors.groupingBy(Grade::getGrade, Collectors.counting()));
        m.put("lastYearGrades", gradeDist);

        return ResponseEntity.ok(m);
    }

    /**
     * Register a new student for a course (demonstrates persistent write)
     * Request body: { "studentRoll": "19CS1234" }
     * Returns 201 with the created registration id and new registration count.
     */
    @PostMapping("/courses/{code}/register")
    @Transactional
    public ResponseEntity<?> registerStudent(@PathVariable("code") String code, @RequestBody Map<String, String> body) {
        String roll = body.get("studentRoll");
        if (roll == null || roll.isBlank()) {
            log.warn("Registration request with empty studentRoll for course {}", code);
            return ResponseEntity.badRequest().body(Map.of("error", "studentRoll is required"));
        }
        Optional<Course> oc = courseRepo.findByCourseCode(code);
        if (oc.isEmpty()) {
            log.warn("Attempt to register to unknown course {}", code);
            return ResponseEntity.notFound().build();
        }
        Course course = oc.get();
        Registration r = new Registration();
        r.setCourseId(course.getId());
        r.setStudentRoll(roll);
        regRepo.save(r);

        long newCount = regRepo.countByCourseId(course.getId());
        log.info("Registered student {} to course {} (new count={})", roll, code, newCount);

        return ResponseEntity.status(201).body(Map.of("registrationId", r.getId(), "registeredStudents", newCount));
    }

    /**
     * Update course metadata (e.g., content or instructor) to demonstrate persistence.
     * Request body can include any of: courseName, instructor, content, semester
     */
    @PutMapping("/courses/{code}")
    @Transactional
    public ResponseEntity<?> updateCourse(@PathVariable("code") String code, @RequestBody Map<String, String> body) {
        log.info("Update request for course {} with body {}", code, body);
        Optional<Course> oc = courseRepo.findByCourseCode(code);
        if (oc.isEmpty()) {
            log.warn("Attempt to update unknown course {}", code);
            return ResponseEntity.notFound().build();
        }
        Course c = oc.get();
        boolean changed = false;
        if (body.containsKey("courseName")) { c.setCourseName(body.get("courseName")); changed = true; }
        if (body.containsKey("instructor")) { c.setInstructor(body.get("instructor")); changed = true; }
        if (body.containsKey("content")) { c.setContent(body.get("content")); changed = true; }
        if (body.containsKey("semester")) { c.setSemester(body.get("semester")); changed = true; }

        if (changed) {
            courseRepo.save(c);
            log.info("Course {} updated successfully", code);
            return ResponseEntity.ok(Map.of("updated", true, "courseId", c.getId()));
        } else {
            log.debug("No updatable fields provided for course {}", code);
            return ResponseEntity.badRequest().body(Map.of("updated", false, "reason", "no fields provided"));
        }
    }
}
