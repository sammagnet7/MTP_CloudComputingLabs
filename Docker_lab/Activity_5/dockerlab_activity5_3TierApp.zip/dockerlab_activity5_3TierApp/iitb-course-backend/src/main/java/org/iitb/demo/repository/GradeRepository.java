package org.iitb.demo.repository;

import org.iitb.demo.model.Grade;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface GradeRepository extends JpaRepository<Grade, Long> {
    List<Grade> findByCourseIdAndYear(Long courseId, Integer year);
}
