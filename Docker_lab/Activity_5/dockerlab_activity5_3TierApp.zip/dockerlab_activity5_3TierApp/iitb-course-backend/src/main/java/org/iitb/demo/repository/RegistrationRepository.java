package org.iitb.demo.repository;

import org.iitb.demo.model.Registration;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RegistrationRepository extends JpaRepository<Registration, Long> {
    long countByCourseId(Long courseId);
}
