-- V1__init_schema_and_data.sql (use bigserial for IDs)
CREATE TABLE IF NOT EXISTS courses (
  id bigserial PRIMARY KEY,
  course_code varchar(50) UNIQUE NOT NULL,
  course_name varchar(255),
  instructor varchar(255),
  content text,
  semester varchar(50)
);

CREATE TABLE IF NOT EXISTS registrations (
  id bigserial PRIMARY KEY,
  course_id bigint REFERENCES courses(id),
  student_roll varchar(50)
);

CREATE TABLE IF NOT EXISTS grades (
  id bigserial PRIMARY KEY,
  course_id bigint REFERENCES courses(id),
  grade varchar(10),
  year integer
);

-- seed rows
INSERT INTO courses (course_code, course_name, instructor, content, semester) VALUES
('CS601', 'Advanced Algorithms', 'Prof. R. Kannan', 'Graph algorithms, randomized algorithms, NP-hardness, approximation', 'Autumn 2025'),
('CS602', 'Distributed Systems', 'Prof. S. K. Das', 'Consensus, replication, failure models, CAP theorem', 'Autumn 2025'),
('CS603', 'Machine Learning', 'Prof. A. Gupta', 'Supervised learning, neural networks, optimization', 'Spring 2025');

INSERT INTO registrations (course_id, student_roll) VALUES
(1,'19CS1001'), (1,'19CS1002'), (1,'19CS1003'), (1,'19CS1004'),
(2,'19CS1005'), (2,'19CS1006'),
(3,'19CS1007'), (3,'19CS1008'), (3,'19CS1009');

INSERT INTO grades (course_id, grade, year) VALUES
(1,'A',2024),(1,'A',2024),(1,'B',2024),(1,'C',2024),
(2,'A',2024),(2,'B',2024),
(3,'A',2024),(3,'A',2024),(3,'A',2024);
