# 📚 IITB Course Frontend (Demo App)

This is a **React-based frontend** for the IIT Bombay Courses demo.
It consumes the backend REST APIs (`/api/**`) served by the **Spring Boot backend** and provides an attractive, animated interface for browsing and interacting with courses.

---

## ✨ Features

* 📖 View all running courses (code, name, instructor, semester, student count, grade distribution).
* 🔍 View detailed information about a single course.
* 📝 Register new students dynamically (persists in DB).
* 🎨 Animated UI using **Framer Motion** and a custom modern design.
* ⚡ Configurable backend API URL via environment variable — **no rebuild required**.

---

## 🛠️ Local Development (without Docker)

1. Install dependencies:

   ```bash
   npm install
   ```

2. Run in dev mode (proxy to backend on `http://localhost:8080` recommended):

   * Add this to `package.json`:

     ```json
     "proxy": "http://localhost:8080"
     ```
   * Then:

     ```bash
     npm start
     ```
   * App will run at `http://localhost:3000`

---

## 🐳 Running with Docker

### 1. Build the image

From the project root:

```bash
docker build -t iitb-course-frontend .
```

### 2. Run the container

Point the frontend to your backend API by passing `REACT_APP_API_BASE_URL`:

```bash
docker run -d \
  --name frontend \
  -p 3000:80 \
  -e REACT_APP_API_BASE_URL="http://x.x.x.x:8080" \
  iitb-course-frontend
```

* `-p 3000:80` → exposes app at `http://localhost:3000`.
* `REACT_APP_API_BASE_URL` → backend base URL.

  * Example: `http://x.x.x.x:8080` (if backend is running on host).
  * If empty, frontend assumes same-origin `/api/...`.

---

## 🔗 How frontend finds backend

At container start, the script generates `env-config.js` from the environment variable:

```bash
REACT_APP_API_BASE_URL="http://x.x.x.x:8080"
```

Frontend reads it at runtime (`window._env_`) and directs API calls there.
This means you **do not need to rebuild** when backend URL changes — just set the env var when running.

---

## 🖥️ Example Demo Setup

Run **Postgres**, **backend**, and **frontend** together:

```bash
# 1. Run backend (already built/pushed to Docker Hub)
docker run -d \
  --name backend \
  -p 8080:8080 \
  -e SPRING_DATASOURCE_URL=jdbc:postgresql://postgres:5432/demo_db \
  -e SPRING_DATASOURCE_USERNAME=demo_user \
  -e SPRING_DATASOURCE_PASSWORD=demo_pass \
  your-dockerhub-user/iitb-course-backend:latest

# 2. Run frontend
docker run -d \
  --name frontend \
  -p 3000:80 \
  -e REACT_APP_API_BASE_URL="http://x.x.x.x:8080" \
  your-dockerhub-user/iitb-course-frontend:latest
```

Then open 👉 **[http://localhost:3000](http://localhost:3000)**

---

## 🚀 Endpoints exposed by frontend

* `/` → Course Explorer UI
* Calls backend APIs:

  * `GET /api/courses` → list all courses
  * `GET /api/courses/{code}` → detailed course info
  * `POST /api/courses/{code}/register` → register new student

---

## ⚠️ Notes

* This demo **enables CORS for all origins** in the backend. Do not use this config in production.
* Replace `x.x.x.x` with your actual host IP when running containers.
* Make sure backend is running and accessible before using the frontend.

---
