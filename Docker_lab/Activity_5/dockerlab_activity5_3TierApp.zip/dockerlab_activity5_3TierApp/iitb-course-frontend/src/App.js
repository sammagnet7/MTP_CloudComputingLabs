import React from 'react';
import CourseList from './components/CourseList';

export default function App(){
  return (
    <div className="container">
      <header className="header">
        <div className="logo">
          <div className="mark">IITB</div>
          <div className="title">IIT Bombay — Courses Explorer</div>
        </div>
        <div className="controls">
          <button className="btn" onClick={()=>window.location.reload()}>Refresh</button>
        </div>
      </header>

      <main>
        <CourseList />
      </main>
    </div>
  );
}