import React, { useEffect, useState } from 'react';
import api from '../api';
import { motion, AnimatePresence } from 'framer-motion';
import CourseModal from './CourseModal';

export default function CourseList(){
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState(null);

  async function fetchCourses(){
    try{
      setLoading(true);
      const res = await api.get('/api/courses');
      setCourses(res.data);
    }catch(err){
      console.error(err);
      alert('Failed to fetch courses. Ensure backend is running and REACT_APP_API_BASE_URL is set correctly');
    }finally{ setLoading(false); }
  }

  useEffect(()=>{ fetchCourses(); }, []);

  return (
    <div>
      <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
        <h2 style={{color:'#c7d2fe'}}>Running Courses</h2>
        <div className='small'>{loading ? 'Loading...' : `${courses.length} courses`}</div>
      </div>

      <div className="grid" style={{marginTop:16}}>
        <AnimatePresence>
        {courses.map(c=>(
          <motion.div key={c.courseCode} className="card"
            initial={{opacity:0, y:10, scale:0.98}} animate={{opacity:1, y:0, scale:1}} exit={{opacity:0, y:10}}
            transition={{duration:0.35}}>
            <div className="course-code">{c.courseCode}</div>
            <div className="course-name">{c.courseName}</div>
            <div className="instructor">Instructor: {c.instructor}</div>
            <div className="meta">
              <div className="chips">Semester: {c.semester}</div>
              <div className="chips">Students: {c.registeredStudents ?? 0}</div>
            </div>
            <div className="footer">
              <div className="small">Grades last year: {Object.keys(c.lastYearGrades||{}).length} types</div>
              <button className="view-btn" onClick={()=>setSelected(c.courseCode)}>View</button>
            </div>
          </motion.div>
        ))}
        </AnimatePresence>
      </div>

      <AnimatePresence>
        {selected && <CourseModal code={selected} onClose={()=>setSelected(null)} />}
      </AnimatePresence>
    </div>
  );
}