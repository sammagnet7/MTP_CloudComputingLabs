import React, { useEffect, useState } from 'react';
import api from '../api';
import { motion } from 'framer-motion';

export default function CourseModal({ code, onClose }){
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [newRoll, setNewRoll] = useState('');

  useEffect(()=>{
    let mounted=true;
    setLoading(true);
    api.get(`/api/courses/${code}`).then(res=>{ if(mounted) setData(res.data); }).catch(err=>{ console.error(err); alert('Failed to fetch course'); }).finally(()=>setLoading(false));
    return ()=> mounted=false;
  }, [code]);

  async function register(){
    if(!newRoll) return alert('Enter roll');
    try{
      const res = await api.post(`/api/courses/${code}/register`, { studentRoll: newRoll });
      alert('Registered: ' + JSON.stringify(res.data));
      // refresh details
      const d = await api.get(`/api/courses/${code}`);
      setData(d.data);
      setNewRoll('');
    }catch(err){ console.error(err); alert('Register failed'); }
  }

  if(!data) return null;

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <motion.div className="modal" onClick={e=>e.stopPropagation()}
        initial={{scale:0.9, opacity:0}} animate={{scale:1, opacity:1}} exit={{scale:0.9, opacity:0}} transition={{duration:0.25}}>
        <button className="close" onClick={onClose}>✕</button>
        <h3 style={{fontSize:20, marginBottom:6}}>{data.courseName} <span className="course-code" style={{fontSize:12, marginLeft:8}}>{data.courseCode}</span></h3>
        <div className="small">Instructor: {data.instructor}</div>
        <p style={{marginTop:12}}>{data.content}</p>

        <table className="table">
          <thead><tr><th>Metric</th><th>Value</th></tr></thead>
          <tbody>
            <tr><td>Semester</td><td>{data.semester}</td></tr>
            <tr><td>Registered Students</td><td>{data.registeredStudents ?? 0}</td></tr>
            <tr><td>Last Year Grades</td><td>{Object.entries(data.lastYearGrades||{}).map(([g,c])=>`${g}: ${c}`).join(', ')}</td></tr>
          </tbody>
        </table>

        <div style={{marginTop:12, display:'flex', gap:8, alignItems:'center'}}>
          <input value={newRoll} onChange={e=>setNewRoll(e.target.value)} placeholder="19CS1234" style={{padding:8, borderRadius:8, border:'none'}} />
          <button className="view-btn" onClick={register}>Register</button>
        </div>
      </motion.div>
    </div>
  );
}