#!/bin/sh
set -e

# Default to empty if not provided (so app uses same-origin)
: "${REACT_APP_API_BASE_URL:=}"

if [ -f /usr/share/nginx/html/env-config.template.js ]; then
  echo "Rendering env-config.js with REACT_APP_API_BASE_URL=${REACT_APP_API_BASE_URL}"
  export REACT_APP_API_BASE_URL
  envsubst '${REACT_APP_API_BASE_URL}' < /usr/share/nginx/html/env-config.template.js > /usr/share/nginx/html/env-config.js
fi

exec "$@"
